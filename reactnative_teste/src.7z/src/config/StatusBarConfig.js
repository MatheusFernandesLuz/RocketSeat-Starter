import { StatusBar } from 'react-native';

StatusBar.setBackgroundColor('#DA552F');
StatusBar.setBarStyle('light-content');
