import React, { Component } from 'react';
import api from '../services/api';

import { View, Text } from 'react-native';

export default class Main extends Component {
  static navigationOptions = {
    title: 'JSHunt',
  };

  state = {
    counter: 0,
  };

  componentDidMount() {
    this.loadProducts();
  }

  loadProducts = async () => {
    const response = await api.get('/produtos');

    const { docs } = response.data;

    this.setState({ counter: docs.lenght });
  };

  render() {
    return (
      <View>
        <Text>Página Main: {counter.}</Text>
      </View>
    );
  }
}
